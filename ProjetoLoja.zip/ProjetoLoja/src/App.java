import controllers.ProdutoController;

public class App {
    public static void main(String[] args) throws Exception {
        ProdutoController controller = new ProdutoController(); 
        controller.iniciar();
    }
}
